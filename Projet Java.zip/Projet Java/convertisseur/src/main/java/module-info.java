module com.lina {
    requires javafx.controls;
    requires javafx.fxml;
    requires transitive javafx.graphics;
    requires javafx.media;
    requires java.net.http;     // pour HttpClient
    requires com.google.gson;  // pour Gson API JSON

    opens com.lina to javafx.fxml;
    exports com.lina;
}